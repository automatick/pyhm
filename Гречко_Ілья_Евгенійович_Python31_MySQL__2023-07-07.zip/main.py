from mysql.connector import connect, Error
from os import getenv# Что бы получить переменные среды импортируемые из файла
from dotenv import load_dotenv# Что бы загрузить переменные среды из файла
from sys import stdout, stderr# Эти функции быстрее в 2 раза чем обычный print
from atexit import register# Выполнить функцию после завершения работы


load_dotenv("pass.env")

def conn(dbname):
	try:
		a = connect(host='localhost', user=getenv('USER'), password=getenv('PASSWORD'), database='mysql')
		b = a.cursor()
		try:
			b.execute(f"USE {dbname};")
		except Error as e:
			b.execute(f"CREATE DATABASE {dbname};")
			stdout.write("Database created.\n")
		def end():
			try:
				a.commit()
				a.close()
				b.close()
			except:
				a.close()
				b.close()
		register(end)
		return a, b
	except Error as e:
		stderr.write(f"Найдена ошибка: {e}\n")


a, b = conn("vgfr")
# b.execute("CREATE TABLE fruits_and_vegetables (name varchar(50) PRIMARY KEY, type varchar(7), color varchar(10), ccal int, description varchar(100))")
# b.execute("INSERT INTO fruits_and_vegetables VALUES('apple', 'fruit', 'yellow', 100, 'just a fruit');")


def ccal(num, cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables WHERE ccal < {num};")
	return cursor.fetchall()


def ccal_ft(frm, to,cursor):
	if frm > to:
		tmp = frm
		frm = to
		to = tmp
	cursor.execute(f"SELECT * FROM fruits_and_vegetables WHERE ccal <= {to} AND ccal >= {frm};")
	return cursor.fetchall()


def nm(name, cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables WHERE name LIKE '%{name}%';")
	return cursor.fetchall()


def nm_dsc(name, cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables WHERE description LIKE '%{name}%';")
	return cursor.fetchall()


def nm_tp(cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables WHERE type = 'yellow' OR type = 'red';")
	return cursor.fetchall()


def _count(type, cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables WHERE type = '{type}'")
	return len(cursor.fetchall())

def ct_vg(cursor):
	return _count("vegetable", cursor)

def ct_ft(cursor):
	return _count("fruit", cursor)

def cnt_clr(color, cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables WHERE color = '{color}'")
	return len(cursor.fetchall())

def cnt_all_clr(cursor):
	cursor.execute(f"SELECT COUNT(color) FROM fruits_and_vegetables")
	return cursor.fetchall()

def sl_clr_mn(cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables")
	return cursor.fetchone()


def sl_clr_mn(cursor):
	cursor.execute(f"SELECT * FROM fruits_and_vegetables")
	return cursor.fetchall()


def rt_mn_ccl(cursor):
	cursor.execute(f"SELECT MIN(ccal) FROM fruits_and_vegetables")
	return cursor.fetchone()


def rt_mx_ccl(cursor):
	cursor.execute(f"SELECT MAX(ccal) FROM fruits_and_vegetables")
	return cursor.fetchone()


def rt_avg_ccl(cursor):
	cursor.execute(f"SELECT AVG(ccal) FROM fruits_and_vegetables")
	return float(cursor.fetchone()[0])



def rt_mn_ccls(cursor):
	cursor.execute(f"SELECT MIN(ccal) FROM fruits_and_vegetables")
	a = cursor.fetchone()
	cursor.execute(f"SELECT name FROM fruits_and_vegetables WHERE ccal = {a[0]}")
	return cursor.fetchone()


def rt_mx_ccls(cursor):
	cursor.execute(f"SELECT MAX(ccal) FROM fruits_and_vegetables")
	a = cursor.fetchone()
	cursor.execute(f"SELECT name FROM fruits_and_vegetables WHERE ccal = {a[0]}")
	return cursor.fetchone()