from datetime import datetime
class Car():
    def __init__(self):
        self.car_name: str = "BMW"
        self.age_date: datetime = datetime.now()
        self.creator: str = "None"
        self.engine_lt: str = "None"
        self.color: str = "None"
        self.price: str = "None"

    def crush_car(self, *args):
        for i in args:
                if i == "car_name":
                    self.car_name = "None"
                if i == "age_date":
                    self.age_date = datetime.now()
                if i == "creator":
                    self.creator = "None"
                if i == "engine_lt":
                    self.engine_lt = "None"
                if i == "color":
                    self.color = "None"
                if i == "price":
                    self.price = "None"

    def change_info(self, **kwargs):
        for nm, vl in kwargs.items():
            if nm == "car_name":
                self.car_name = vl
            if nm == "age_date":
                self.age_date = vl
            if nm == "creator":
                self.creator = vl
            if nm == "engine_lt":
                self.engine_lt = vl
            if nm == "color":
                self.color = vl
            if nm == "price":
                self.price = vl
            if nm == "age_date":
                date_type = "%Y-%m-%d"
                self.age_date = datetime.strptime(vl, date_type)

    def show_info(self, *args):
        for i in args:
            if i == "car_name":
                print(self.car_name)
            if i == "age_date":
                print(self.age_date)
            if i == "creator":
                print(self.creator)
            if i == "engine_lt":
                print(self.engine_lt)
            if i == "color":
                print(self.color)
            if i == "price":
                print(self.price)

a = Car()
print(a.car_name)
a.change_info(car_name="BMWic")
print(a.show_info("car_name"))
a.change_info(age_date="2020-01-01")
a.kill_human("car_name")
a.show_info("age_date")
print(a.car_name)