class Figure:
    def __init__(self, a, b, c, d, r):
        self.left_side = a
        self.right_side = c
        self.top_side = b
        self.bottom_side = d
        self.radius = r
        self._area = 0

    def __int__(self):
        return self._area

    def __str__(self):
        return f"Left side: {self.left_side} Right side: {self.right_side} Top side: {self.top_side} Bottom side: {self.bottom_side} Radius: {self.radius}"

    def area(self):
        self._area = self.top_side * self.top_side
        return self._area


class Rectangle(Figure):
    def __init__(self, a, b):
        super().__init__(a, b, 0, 0, 0)

    def area(self):
        self._area = self.top_side * self.top_side
        return self._area


class Circle(Figure):
    def __init__(self, r):
        super().__init__(0, 0, 0, 0, r)

    def area(self):
        self._area = self.radius * self.radius * 3.14
        return self._area


class Right_triangle(Figure):
    def __init__(self, a, b):
        super().__init__(a, b, 0, 0, 0)

    def area(self):
        self._area = 1/2 * self.left_side * self.right_side
        return self._area


class Trapezium(Figure):
    def __init__(self, a, b, c):
        super().__init__(a, b, c, 0, 0)

    def area(self):
        self._area = (self.left_side + self.right_side) * self.top_side / 2
        return self._area  # top side - bottom side

if __name__ == '__main__':
    a = Trapezium(1, 2, 3)
    print(a.area())

#3rd
class Shape:
    def __init__(self, a, b, r):
        self.left_side = a
        self.top_side = b
        self.radius = r

    def show(self):
        return f"Left side: {self.left_side} Right side: {self.right_side} Top side: {self.top_side} Bottom side: {self.bottom_side} Radius: {self.radius}"            

    def load(self):
        with open("figure.txt", "r") as f:
            return f.readlines()

    def save(self):
        with open("figure.txt", "w") as f:
            f.write(self.draw)


class Square(Shape):
    def __init__(self, a):
        super().__init__(a, 0, 0)

    def draw(self):
        for i in range(self.left_side):
            print("*  "*self.left_side)
        print()

class Rectanglee(Shape):
    def __init__(self, a, b):
        super().__init__(a, b, 0)

    def draw(self):
        for i in range(self.left_side):
            print("*  "*self.top_side)
        print()


class Circlee(Shape):
    def __init__(self, r):
        super().__init__(0, 0, r)

    def draw(self):
        a = self.radius - 1
        r = False
        for i in range(self.radius*2):
            print(a*" "+"*"*2*(self.radius-a))
            if r == False:
                a -= 1
            else:
                a += 1
            if a == 0:
                r = True
        print()


Square(5).draw()
Rectanglee(2, 7).draw()
Circlee(4).draw()