import os
import socket


HEADER = 64
PORT = 3000
DISCONNECT_MESSAGE = "!EXIT"
SERVER = '192.168.1.2'
ADDR = (SERVER, PORT)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(ADDR)

def send(msg):
    message = msg.encode('utf-8')
    msg_len = len(message)
    send_len = str(msg_len).encode('utf-8')
    send_len += b' ' * (HEADER - len(send_len))
    client.send(send_len)
    client.send(message)
    print(client.recv(4096).decode('utf-8').replace("^", "\n"))

while True:
    try:
        msg = input()
        os.system('cls')
        send(msg)
    except KeyboardInterrupt:
        send(DISCONNECT_MESSAGE)
        exit(1)
