import socket
import threading
import random as rn
import string as st


PORT = 3000
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
HEADER = 64
DISCONNECT_MESSAGE = "!EXIT"
msg_history = []

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(ADDR)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

def client_func(conn, addr):
    print(f"New connection: {addr} connected.")
    connected = True
    while connected:
        msg_len = conn.recv(HEADER).decode('utf-8')
        if msg_len:
            msg_len = int(msg_len)
            msg = conn.recv(msg_len).decode('utf-8')
            if msg == DISCONNECT_MESSAGE:
                connected = False
            print(f'{addr} -> {msg}')
            snd_msg = "^".join(msg_history)
            snd_msg += f'{addr} -> {msg}^'
            snd_msg += 'SERVER -> '
            snd_msg += "".join([rn.choice(st.ascii_letters) for i in range(10)])
            snd_msg += "^"
            msg_history.append(snd_msg)
            conn.send(snd_msg.encode('utf-8'))
    conn.close()


def start():
    server.listen()
    print(f"Server starts on {SERVER}")
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=client_func, args=(conn, addr))
        thread.start()
        print(f"Active connections: {threading.active_count() - 1}")

print("Starting server...")
start()
