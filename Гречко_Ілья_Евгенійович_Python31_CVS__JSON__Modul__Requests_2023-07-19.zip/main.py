import bs4
import requests as rq
from time import perf_counter
import threading as th

links = [
    'https://xkcd.com/1289/', 'https://xkcd.com/1290/', 'https://xkcd.com/1291/',
    'https://xkcd.com/1292/', 'https://xkcd.com/1293/', 'https://xkcd.com/1294/',
    'https://xkcd.com/1295/', 'https://xkcd.com/1296/', 'https://xkcd.com/1297/',
    'https://xkcd.com/1298/', 'https://xkcd.com/1299/', 'https://xkcd.com/1300/'
]

# for i in links:
# 	soup = bs4.BeautifulSoup(rq.get(i).text, 'html.parser')
# 	with open(f"image{links.index(i)}.png", "wb") as f:
# 		f.write(rq.get("https:"+soup.find_all('img')[2]["src"]).content)

def strtt(num, barrier):
    barrier.acquire()
    start = perf_counter()
    response = rq.get(links[num])
    soup = bs4.BeautifulSoup(response.text, 'html.parser')
    image_url = soup.find(id='comic').find('img')['src']

    with open(f"image{num}.png", "wb") as f:
        f.write(rq.get("https:" + image_url).content)

    end = perf_counter()
    print(f"Thread {num} elapsed time: {end - start:.2f} seconds")
    barrier.release()

if __name__ == '__main__':
    start = perf_counter()
    barrier = th.Semaphore(5)

    threads = [th.Thread(target=strtt, args=(i, barrier)) for i in range(len(links))]
    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    end = perf_counter()
    print(f"Total elapsed time: {end - start:.2f} seconds")


