import random
a = [random.randint(-50, 50) for i in range(10)]
parni = [i for i in a if i % 2 == 0]
neparni = [i for i in a if i % 2 == 1]
videmni = [i for i in a if i < 0]
dodatni = [i for i in a if i > 0]
print(neparni, parni, videmni, dodatni)