#1st 
def format():
	print("“Don’t compare yourself with anyone in this world...\n      if you do so, you are insulting yourself.”\n                             —Bill Gates")
#2nd
def parni(a,b):
	for i in range(a, b+1):
		if i % 2 == 0:
			print(i)
#3rd
def kvadrat(a, b, c):
	if c:
		for i in range(a):
			print(b*a, end="")
			print()
	else:
		print(b*a)
		for i in range(a-2):
			print(b, " " * (a-3), end=b)
			print()
		print(b*a)
def minimum(a, b, c, d, e):
	v = [a, b, c, d, e]
	return min(v)
result = 1
def dobutok(a, b):
	global result
	if a < b:
		for i in range(a, b+1):
			result *= i
	else:
		for i in range(b, a+1):
			result *= i
	return result
def kolichevstvo(a):
	a = str(a)
	return len(a)
def palindrom(a):
	reversed_string = a[::-1]
	return a == reversed_string

if __name__ == "__main__":
	format()
	parni(int(input(": ")), int(input(": ")))
	kvadrat(int(input(": ")), input(": "), True)
	print(minimum(8, 2, 3, 4, 5))
	print(dobutok(5, 10))
	print(kolichevstvo(4568))
	print(palindrom(input(": ")))