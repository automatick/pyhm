import os
import sys
#1st
# a = int(input("1st number: "))
# b = int(input("1st number: "))
# 
# nekrat = 0
# krat = 0
# nineth = 0
# counekrat = 0 #Количевтво некратных чисел
# coukrat = 0 #Количевство кратных чисел
# counine = 0 #Количевство чисел кратных 9
# 
# for i in range(a, b+1):
#     if (i % 2) != 0:
#         nekrat += i
#         counekrat += 1
#     if (i % 2) == 0:
#         krat += i
#         coukrat += 1
#     if (i % 9) == 0:
#         nineth += i
#         counine += 1
# 
# ser_nekrat = nekrat / counekrat
# ser_krat = krat / coukrat
# ser_nineth = nineth / counine
# 
# 
# print(f"Сумма не кратных двум:{nekrat} Сумма кратных двум:{krat} Сумма чисел кратных девяти:{nineth} Среднее некратных двум:{ser_nekrat} Среднее кратных двум:{ser_krat} Среднее чисел кратных девяти:{ser_nineth}")
#2nd
# a = int(input("enter a number: "))
# b = input("enter a symbol: ")
# 
# for i in range(0, a):
# 	print(b)
#3rd
# while True:
# 	a = int(input("Enter a number: "))
# 	if a == 7:
# 		print("Goodbye)")
# 		os.system("shutdown /t")
# 	elif a > 0:
# 		print("positive number")
# 	elif a < 0:
# 		print("negative number")
# 	else:
# 		print("zero")
#4th
a = int(input("Enter a min: "))
min = a
max = 0
while True:
    a = int(input("Enter a max: "))
    if a == 7:
        print("goodbye")
        sys.exit(":(")
    elif a < min:
        min = a
        print(min+max)
    elif a > max:
        max = a
        print(max+min)
