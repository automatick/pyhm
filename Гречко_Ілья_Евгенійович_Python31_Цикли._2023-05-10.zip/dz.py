# a = int(input("Enter a number: "))
# b = int(input("Enter a number: "))
# for i in range(a, b+1):
# 	if i % 7 == 0:
# 		print(i)
# class Vtoroe:
# 	def __init__(self):
# 		self.a = int(input("Enter a number: "))
# 		self.b = int(input("Enter a number: "))
# 		self.colpyat = 0
# 	def vse(self):
# 		print("все числа")
# 		for i in range(self.a, self.b+1):
# 			print(i)
# 	def perv(self):
# 		print("Перевернутые")
# 		for i in range(self.b, self.a - 1, -1):
# 			print(i)
# 	def kratnisem(self):
# 		print("Kratny 7")
# 		for i in range(self.b, self.a - 1, -1):
# 			if i % 7 == 0:
# 				print(i)
# 	def kolpat(self):
# 		for i in range(self.a, self.b + 1):
# 			if i % 5 == 0:
# 				self.colpyat += 1
# 		print(self.colpyat)

a = int(input("Enter a number: "))
b = int(input("Enter a number: "))

for i in range(a, b+1):
    if i % 3 == 0:
        print("Fizz")
    if i % 5 ==0:
        print("Buzz")
    if i % 5 == 0 and i % 3 == 0:
        print("FizzBuzz")
    if i%3 != 0 and i%5 != 0:
	    print(i)

