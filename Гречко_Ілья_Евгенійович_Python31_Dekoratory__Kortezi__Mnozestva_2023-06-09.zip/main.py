a = (4, 5, 9)
b = (7, 4, 9)
c = (1, 4, 9)

def al_elem(aa, bb, cc):
	res = ()
	for i in aa:
		for j in bb:
			for k in cc:
				if i == j == k:
					res = res + (i, j, k)
	return tuple(set(res))

def unique_elem(aa, bb, cc):
	res = ()
	res += aa + bb + cc
	return tuple(set(res))

def elem_at_same_index(aa, bb, cc):
	res = ()
	for i in aa:
		for j in bb:
			for k in cc:
				if i == j == k:
					if aa.index(i) == bb.index(j) == cc.index(k):
						res = res + (i, j, k)
	return tuple(set(res))

if __name__ == "__main__":
	print(al_elem(a, b, c))
	print(unique_elem(a, b, c))
	print(elem_at_same_index(a, b, c))