# 4th
import sqlite3 as sq
from sqlite3 import Error
from atexit import register


def cnct_bd(dbname):
    try:
        conn = sq.connect(dbname)
        cs = conn.cursor()
        print("Opened database successfully.")
    except Error as e:
        print(f"The error '{e}' occurred")
    def end():
        conn.commit()
        cs.close()
        conn.close()
    register(end)
    return conn, cs

a, b = cnct_bd('bll.db')

# a.execute("CREATE TABLE students (name VARCHAR(30), city VARCHAR(10), country VARCHAR(15), birthdate VARCHAR(10), email VARCHAR(30), phone INTEGER, groupe VARCHAR(12), avg_year SMALLINT, nm_ls_min VARCHAR(15), nm_ls_max VARCHAR(15))")
# b.execute("INSERT INTO students VALUES ('jonh', 'kyiv', 'ukraine', '12-02-23', 'abcd@gmail.com', 38096452341, 'Python31', 10, 'history', 'math')")
# 5th

def show_all(cursor):
    try:
        cursor.execute("SELECT * FROM students")
        rows = cursor.fetchall()
        return rows
    except Error as e:
        print(f"The error '{e}' occurred, check your database conection.")

def _show(cursor, type, var):
    try:
        cursor.execute(f"SELECT * FROM students WHERE {var} = '{type}'")
        rows = cursor.fetchall()
        return rows
    except Error as e:
        print(f"The error '{e}' occurred, please check the table.")

def show_all_names(cursor):
    cursor.execute("SELECT name FROM students")
    rows = cursor.fetchall()
    return rows


def show_all_avg(cursor):
    cursor.execute("SELECT name, avg_year FROM students")
    rows = cursor.fetchall()
    return rows

def min_plus(cursor, bl):
    cursor.execute(f"SELECT name, avg_year FROM students WHERE avg_year > {bl}")
    rows = cursor.fetchall()
    return rows

def sh_all_unq_countries(cursor):
    cursor.execute("SELECT DISTINCT country FROM students")
    rows = cursor.fetchall()
    return rows

def sh_all_unq_cityes(cursor):
    cursor.execute("SELECT DISTINCT city FROM students")
    rows = cursor.fetchall()
    return rows

def sh_all_unq_groups(cursor):
    cursor.execute("SELECT DISTINCT groups FROM students")
    rows = cursor.fetchall()
    return rows


def sh_all_unq_min_les(cursor):
    cursor.execute("SELECT DISTINCT nm_ls_min FROM students")
    rows = cursor.fetchall()
    return rows

