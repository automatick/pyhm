def dobutok(spisok: list) -> int or float:
	res = 1
	for i in spisok:
		res *= i
	return res

def minimal(spisok: list) -> int or float:
	return min(spisok)

def simple_numbers_count(spisok: list) -> int:
	count = 0
	for j in spisok:
		if j > 2:
			is_prime = True
			for i in range(2, j):
				if j % i == 0:
					is_prime = False
					break
			if is_prime:
				count += 1
	return count

def delete_numbers(spisok: list, num: int or float) -> int:
	res = 0
	for i in spisok:
		if i == num:
			res += 1
	return res

def list_to_list(spisok: list, spisok2: list) -> list:
	return spisok + spisok2

def stepen (spisok: list, num: int) -> list:
	result = []
	for i in spisok:
		if i != 0:
			result.append(abs(i) ** num)
		else:
			result.append(1)
	return result

if __name__ == '__main__':
	spisoks1 = [1, 2, 3, 4, 5, -1, 0, -1]
	spisoks2 = [1, 2, 3, 4, 5, -1, 0]
	print(dobutok(spisoks1))
	print(minimal(spisoks1))
	print(simple_numbers_count(spisoks1))
	print(delete_numbers(spisoks1, -1))
	print(list_to_list(spisoks1, spisoks2))
	print(stepen(spisoks1, 2))