a = [1, 2, 3, 4, 5]
b = [4, 8, 5, 4, 8]
#1st
# c = a+b
# print(c)
#2nd
# result = ""
# for i in a:
# 	if not str(i) in result:
# 		result += str(i)+" "
# 	for j in b:
# 		if not str(j) in result:
# 			result += str(j)+" "
# print(result.split(" "))
#  # або
# с = list(set(a+b))
# print(с)
#3rd
# result = ""
# for i in a:
# 	for j in b:
# 		if i == j:
# 			if str(i) not in result:
# 				result += str(i)+" "
# print(result)
#5rd
# print(f"Min a: {min(a)}, Max a: {max(a)} Min b: {min(b)}, Max b: {max(b)}")
