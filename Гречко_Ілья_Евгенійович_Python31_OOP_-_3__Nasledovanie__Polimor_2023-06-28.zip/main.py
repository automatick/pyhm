from sys import stdout


class Device:
    def __init__(self, name, code, date, price, count):
        self.name = name
        self.address = code
        self.date = date
        self.price = price
        self.count = count

    def set_args(self, attr, value):
        setattr(self, attr, value)

    def get_args(self, arg, log=True):
        if log:
            stdout.write(f"{arg}: {getattr(self, arg)}\n")
            return getattr(self, arg)
        else:
            return getattr(self, arg)

    def sell(self, count=1):
        self.count -= count


class CofeeMachine(Device):
    def __init__(self, name, code, date, liters, price, count, garanty):
        super().__init__(name, code, date, price, count)
        self.liters = liters
        self.garanty = garanty


class Blender(Device):
    def __init__(self, name, code, date, capacity, price, count, garanty, speed, gift="Cat you can find cat in blender."):
        super().__init__(name, code, date, price, count)
        self.capacity = capacity
        self.garanty = garanty
        self.speed = speed
        self.gift = gift


class MeatGrinder(Device):
    def __init__(self, name, code, date, capacity, price, count, garanty, speed, fasteners):
        super().__init__(name, code, date, price, count)
        self.capacity = capacity
        self.garanty = garanty
        self.speed = speed
        self.fasteners = fasteners


if __name__ == "__main__":
    a = Blender("Blender", "Blender", "2020/01/01", 1, 100, 1, 1, 1)
    a.get_args("count")
    a.sell(1)
    a.get_args("count")


class Ship:
    def __init__(self, name, date, price, count_of_humans, count_of_ships):
        self.name = name
        self.date = date
        self.price = price
        self.count_of_ships = count_of_ships
        self.count_of_humans = count_of_humans

    def set_args(self, attr, value, log=False):
        if log:
            stdout.write(f"Attribute {attr} set to value {value}\n")
            setattr(self, attr, value)
        else:
            setattr(self, attr, value)

    def get_args(self, arg, log=True):
        if log:
            stdout.write(f"{arg}: {getattr(self, arg)}\n")
            return getattr(self, arg)
        else:
            return getattr(self, arg)

    def sell(self, count=1):
        self.count -= count

    def titanic(self):
        self.count_of_humans = 0
        self.date = "14/1912"


class Frigate(Ship):
    def __init__(self, name, date, price, count_of_humans, count_of_ships, speed):
        super().__init__(name, date, price, count_of_humans, count_of_ships)
        self.speed = speed

class Destroyer(Ship):
    def __init__(self, name, date, price, count_of_humans, count_of_ships, defense, speed):
        super().__init__(name, date, price, count_of_humans, count_of_ships)
        self.speed = speed
        self.defense = defense

class Cruiser(Ship):
    def __init__(self, name, date, price, count_of_humans, count_of_ships, speed, max_humans):
        super().__init__(name, date, price, count_of_humans, count_of_ships)
        self.speed = speed
        self.max_humans = max_humans

