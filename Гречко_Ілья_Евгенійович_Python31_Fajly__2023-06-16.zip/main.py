with open("test.txt", "r") as f:
	lfs = f.readlines()

with open("newtest.txt") as f:
	fls = f.readlines()

def counting(one, two):
	ress = ""
	for i in one:
		for j in two:
			if i == j:
				ress += i
	return ress


if len(lfs) > len(fls):
	print(counting(lfs, fls))
else:
	print(counting(fls, lfs))

#2nd
with open("test.txt", "r") as f:
	lfs = f.read()
	with open("stat.txt", "w+") as fl:
		tmp = lfs
		tmp = tmp.replace("\n", "")
		tmp = tmp.replace(" ", "")
		length = len(lfs.split('\n'))
		golos = ["a", "e", "i", "o", "u", "y"]
		count = 0
		import string as st
		for i in golos:
			if i in st.ascii_letters:
				count += tmp.count(i)
		num = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
		countnum = 0
		for i in num:
			countnum += tmp.count(str(i))
		fl.write(f"Symbols: {len(tmp)}\nLines: {length}\nGolosny: {count}\nPrugolosny: {len(tmp)-count}\nNums: {countnum}")

#3rd
with open("test.txt", "r") as f:
	lfs = f.read()
	lfs = lfs.split("\n")

with open("withoutLastRow.txt", "w+") as fl:
	res = ""
	for i in lfs:
		if lfs.index(i) == len(lfs)-1:
			break
		else:
			res += i+"\n"
	fl.write(res)
#4th
with open("test.txt", "r") as f:
	lfs = f.read()
	lfs = lfs.split("\n")
	nums = []
	for i in lfs:
		nums.append(len(i))
	print(max(nums))
#5th
with open("test.txt", "r") as f:
	lfs = f.read()
	print(lfs.count(input("Enter word: ")))
#6th
with open("test.txt", "r") as f:
	lfs = f.read()
	with open("test.txt", "w") as f:
		print(lfs)
		lfs = lfs.replace("\n", " "); lfs = lfs.split(" ")
		print(lfs)
		lfs[lfs.index(input("Enter find word: "))] = input("Enter replace word: ")
		f.write(" ".join(lfs))