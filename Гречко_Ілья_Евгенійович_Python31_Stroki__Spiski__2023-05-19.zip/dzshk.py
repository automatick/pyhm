
# a = input("Введите строку: ")
# if a == a[::-1]:
# 	print("Строка является палиндромом")
# else:
# 	print("Строка не является палиндромом")
#2nd
a = input("Введите строку: ")
b = input("Введите зарезервированое слова через пробел: ")
c = a.split(" ")
d = b.split(" ")
for i in d:
	a = a.replace(i, i.upper())
print(a)
# #3rd
# a = input("Введите строку: ")
# b = [".", "!", "?", ";"]
# countprep = 0
# for i in a:
# 	if i in b:
# 		countprep += 1
# print(countprep)