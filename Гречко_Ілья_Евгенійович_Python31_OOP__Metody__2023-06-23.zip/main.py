#2nd
class Temperature:
	__count = 0
	@staticmethod
	def cel_to_far(cel):
		Temperature.__count += 1
		return round(cel * 1.8 + 32)
	@staticmethod
	def far_to_cel(far):
		Temperature.__count += 1
		return round((far - 32) / 1.8, 2)
	@staticmethod
	def get_count():
		return Temperature.__count

if __name__ == "__main__":
	print(Temperature.cel_to_far(30))
	print(Temperature.far_to_cel(100))
	print(Temperature.get_count())

class Distanse:
	@staticmethod
	def engl_to_mil(engl):
		return engl * 0.621371
	@staticmethod
	def mil_to_engl(mil):
		return mil / 0.621371
	@staticmethod
	def km_to_mil(km):
		return km * 0.621371
	@staticmethod
	def mil_to_km(mil):
		return mil / 0.621371
	@staticmethod
	def km_to_engl(km):
		return km * 0.621371
	@staticmethod
	def engl_to_km(engl):
		return engl * 0.621371

if __name__ == "__main__":
	print(Distanse.engl_to_mil(100))
	print(Distanse.mil_to_engl(100))
	print(Distanse.km_to_mil(100))
	print(Distanse.mil_to_km(100))
	print(Distanse.km_to_engl(100))
	print(Distanse.engl_to_km(100))