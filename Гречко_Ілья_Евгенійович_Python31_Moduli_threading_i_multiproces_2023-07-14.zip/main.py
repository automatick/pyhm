import threading
import random
import math

def fill_list(lst, n):
	for _ in range(n):
		lst.append(random.randint(1, 100))


def main( ):
	num_threads = 3
	num_elements = 10

	data_list = []
	fill_thread = threading.Thread(target = fill_list, args = (data_list, num_elements))

	fill_thread.start()
	fill_thread.join()

	sum_thread = threading.Thread(target = sum_and_print, args = (data_list,))
	avg_thread = threading.Thread(target = average_and_print, args = (data_list,))

	sum_thread.start()
	avg_thread.start()

	sum_thread.join()
	avg_thread.join()


def sum_and_print(lst):
	total_sum = sum(lst)
	print(f"Сума елементів списку: {total_sum}")


def average_and_print(lst):
	avg = sum(lst) / len(lst)
	print(f"Середнє арифметичне значення списку: {avg}")


if __name__ == "__main__":
	main()

def fill_file(file_path, n):
	with open(file_path, 'w') as f:
		for _ in range(n):
			f.write(str(random.randint(1, 100)) + '\n')


def is_prime(num):
	if num <= 1:
		return False
	for i in range(2, int(math.sqrt(num)) + 1):
		if num % i == 0:
			return False
	return True


def factorial(num):
	if num == 0:
		return 1
	return num * factorial(num - 1)


def main( ):
	num_threads = 3
	num_values = 10
	file_path = input("Введіть шлях до файлу: ")

	fill_thread = threading.Thread(target = fill_file, args = (file_path, num_values))

	fill_thread.start()
	fill_thread.join()

	prime_thread = threading.Thread(target = find_primes, args = (file_path,))
	factorial_thread = threading.Thread(target = compute_factorials, args = (file_path,))

	prime_thread.start()
	factorial_thread.start()

	prime_thread.join()
	factorial_thread.join()


def find_primes(file_path):
	primes = []
	with open(file_path, 'r') as f:
		for line in f:
			num = int(line.strip())
			if is_prime(num):
				primes.append(num)
	with open("primes.txt", 'w') as f:
		for prime in primes:
			f.write(str(prime) + '\n')


def compute_factorials(file_path):
	with open(file_path, 'r') as f:
		lines = f.readlines()
	with open("factorials.txt", 'w') as f:
		for line in lines:
			num = int(line.strip())
			f.write(str(factorial(num)) + '\n')


if __name__ == "__main__":
	main()

import os
import shutil


def copy_directory(source_dir, dest_dir):
	try:
		shutil.copytree(source_dir, dest_dir)
		print("Директорію успішно скопійовано!")
	except Exception as e:
		print(f"Виникла помилка при копіюванні: {e}")


def main( ):
	source_dir = input("Введіть шлях до існуючої директорії: ")
	dest_dir = input("Введіть шлях до нової директорії: ")

	copy_thread = threading.Thread(target = copy_directory, args = (source_dir, dest_dir))
	copy_thread.start()
	copy_thread.join()


if __name__ == "__main__":
	main()


def find_files_with_word(directory, word):
	result = []
	for root, dirs, files in os.walk(directory):
		for file in files:
			file_path = os.path.join(root, file)
			with open(file_path, 'r') as f:
				content = f.read()
				if word in content:
					result.append(file_path)
	return result


def censor_words(file_path, forbidden_words_path):
	with open(forbidden_words_path, 'r') as f:
		forbidden_words = [word.strip() for word in f.readlines()]
	with open(file_path, 'r') as f:
		content = f.read()
	for word in forbidden_words:
		content = content.replace(word, '*' * len(word))
	with open(file_path, 'w') as f:
		f.write(content)


def main( ):
	directory = input("Введіть шлях до існуючої директорії: ")
	word_to_find = input("Введіть слово для пошуку: ")
	forbidden_words_path = input("Введіть шлях до файлу зі забороненими словами: ")

	found_files = find_files_with_word(directory, word_to_find)
	merged_content = ""

	for file_path in found_files:
		with open(file_path, 'r') as f:
			merged_content += f.read() + '\n'

	with open("merged_content.txt", 'w') as f:
		f.write(merged_content)

	censor_thread = threading.Thread(target = censor_words, args = ("merged_content.txt", forbidden_words_path))
	censor_thread.start()
	censor_thread.join()


if __name__ == "__main__":
	main()