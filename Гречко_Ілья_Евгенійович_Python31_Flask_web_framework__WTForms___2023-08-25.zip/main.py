from flask import Flask, request
from flask_restful import Resource, Api
import sqlite3
import json

app = Flask(__name__)
api = Api(app)

conn = sqlite3.connect('users.db')
cursor = conn.cursor()
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        login TEXT NOT NULL,
        email TEXT NOT NULL
    )
''')
conn.commit()
conn.close()

class GetUsers(Resource):
    def get(self):
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users')
        users = cursor.fetchall()
        conn.close()
        user_list = [{'id': user[0], 'login': user[1], 'email': user[2]} for user in users]
        return json.dumps(user_list)

class CreateUser(Resource):
    def post(self):
        data = request.get_json()
        login = data['login']
        email = data['email']
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO users (login, email) VALUES (?, ?)', (login, email))
        conn.commit()
        conn.close()
        return {'message': 'Користувач створений успішно!'}

# Клас для видалення користувача
class DeleteUser(Resource):
    def delete(self, user_id):
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
        conn.commit()
        conn.close()
        return {'message': 'Користувач видалений успішно!'}
class UpdateUser(Resource):
    def put(self, user_id):
        data = request.get_json()
        login = data['login']
        email = data['email']
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET login = ?, email = ? WHERE id = ?', (login, email, user_id))
        conn.commit()
        conn.close()
        return {'message': 'Дані користувача оновлені успішно!'}

api.add_resource(GetUsers, '/get')
api.add_resource(CreateUser, '/post')
api.add_resource(DeleteUser, '/delete/<int:user_id>')
api.add_resource(UpdateUser, '/put/<int:user_id>')

if __name__ == '__main__':
    app.run(debug=True)
