import socket
import threading as th
import json

PORT = 6080
SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
DISC_MSG = "!EXIT"
SENDIT_MSG = "!SENDIT"
GET_MGS = "!GET"
file_log = {}
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(ADDR)


def receive_file(connection, file_path):
    with open(f'new_{file_path}', 'wb') as file:
        while True:
            data = connection.recv(1024)
            if data == b'<END>':
                break
            file.write(data)
    print("Файл успішно отримано")

def cli_func(connection, address):
    connect = True
    while connect:
        print("Клієнт підключено:", address)
        file_path = connection.recv(1024).decode()
        if file_path == DISC_MSG:
            connect = False
        elif file_path == GET_MGS:
            connection.send(json.dumps(file_log).encode("utf-8"))
            continue
        elif file_path == SENDIT_MSG:
            connection.send(b'!SENDIT')
            file_path = connection.recv(1024).decode()
            file_log[address[0]+str(address[1])] = file_path
            print(file_log)
            print("Отримано файл:", file_path)
            receive_file(connection, file_path)
        else:
            print("Отримано файл:", file_path)
            connection.send(b'!SENDIT')
            receive_file(connection, file_path)
    connection.close()

def start_server():
    server_socket.listen()
    print(f"Сервер запущено. Очікування підключення...{SERVER}")
    while True:
        conn, addr = server_socket.accept()
        thread = th.Thread(target=cli_func, args=(conn, addr))
        thread.start()

start_server()
