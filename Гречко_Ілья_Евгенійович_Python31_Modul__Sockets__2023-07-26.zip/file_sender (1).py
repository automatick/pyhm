import socket
import json

PORT = 6080
SERVER = '192.168.1.2'
ADDR = (SERVER, PORT)

def send_file(connection, file_path):
    try:
        with open(file_path, 'rb') as file:
            while True:
                data = file.read(1024)
                if not data:
                    break
                connection.sendall(data)
        connection.send(b'<END>')  # Send the end-of-file indication to the server
        print("Файл успішно надіслано")
    except Exception as e:
        print(f"Error while sending file: {e}")

def start_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client_socket.connect(ADDR)
    except ConnectionRefusedError:
        print(f"Не вдалося підключитись до сервера на адресі {SERVER}:{PORT}. Перевірте, чи сервер працює та спробуйте знову.")
        return

    print(f"Підключено до сервера {SERVER}:{PORT}")

    while True:
        file_path = input("Введіть шлях та назву файлу для надсилання (або 'exit' для виходу): ")

        if file_path.lower() == 'exit':
            client_socket.send(b'!EXIT')
            break
        elif file_path == "get":
            client_socket.send(b'!GET')
            log = client_socket.recv(1024).decode("utf-8")
            log = json.loads(log)
            print(log)
            continue

        try:
            with open(file_path, 'rb') as test_file:
                pass
        except FileNotFoundError:
            print("Файл не знайдено. Спробуйте знову.")
            continue

        client_socket.send(b'!SENDIT')  # Inform the server about the intention to send a file
        client_socket.send(file_path.encode())
        response = client_socket.recv(1024)

        if response == b'!SENDIT':
            send_file(client_socket, file_path)
        else:
            print("Сервер відмовив у прийнятті файлу.")

    client_socket.close()

start_client()
