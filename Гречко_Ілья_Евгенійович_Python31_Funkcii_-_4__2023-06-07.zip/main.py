res = 1


def recursive_num(a, n):
	global res
	res *= a
	if a ** n == res:
		res1 = res
		res = 1
		return res1
	else:
		return recursive_num(a, n)

iterations = 0
result = 0
def couple_summ(a, b):
	global result
	global iterations
	if iterations == 0:
		iterations = a
	result += iterations
	if iterations == b:
		res1 = result
		iterations = 0
		result = 0
		return res1
	else:
		iterations += 1
		return couple_summ(result, b)

stars = 1
count = 0
def star_line(a):
	global stars
	global count
	count = a
	print("*", end = "")
	if count == stars:
		stars = 0
		return 0
	else:
		stars += 1
		return star_line(count)

class GameTOE:
	def __init__(self):
		self.game = [
			["1", "2", "3"],
			["4", "5", "6"],
			["7", "8", "9"]
		]
		self.player1_side = input("Выберите сторону 1st player, напишите 'х' или 'о' для выбора стороны\n: ")
		if self.player1_side == "o":
			self.player2_side = "x"
		else:
			self.player2_side = "o"
		self.choise = ""
		self.gameloop = True
		self.rotation = 0
		self.count_of_rotations = 0
		self.ban_nums = []
		self.correct = 0
		if self.player1_side == "x" or self.player1_side == "o":
			pass
		else:
			print("Неправильная сторона.")
			exit()
	def start(self):
		def player_rotation(choise, player_side):
			if choise < 4:
				self.game[0][choise - 1] = player_side
			elif choise < 7:
				choise -= 4
				self.game[1][choise] = player_side
			elif choise < 10:
				choise -= 7
				self.game[2][choise] = player_side
			else:
				print("Неправильная клетка.")
		while self.gameloop:
			print(self.game[0], "\n", self.game[1], "\n", self.game[2], sep = "")
			if self.rotation == 0:
				self.count_of_rotations += 1
				self.rotation = 1
				while self.correct == 0:
					self.choise1 = int(input("Введите номер клетки где player1 хотите поставить ваш символ: "))
					if self.choise1 in self.ban_nums:
						print("Это число занято!")
					else:
						self.correct = 1
				self.ban_nums.append(self.choise1)
				self.correct = 0
				player_rotation(self.choise1, self.player1_side)
			else:
				self.count_of_rotations += 1
				self.rotation = 0
				while self.correct == 0:
					self.choise2 = int(input("Введите номер клетки где player2 хотите поставить ваш символ: "))
					if self.choise2 in self.ban_nums:
						print("Это число занято!")
					else:
						self.correct = 1
				self.ban_nums.append(self.choise1)
				self.correct = 0
				player_rotation(self.choise2, self.player2_side)
			for i in self.game:
				if i[0] == i[1] and i[1] == i[2]:
					self.gameloop = False
					print("Победил игрок под символом", i[0])
			if self.game[0][0] == self.game[1][1] and self.game[1][1] == self.game[2][2]:
				self.gameloop = False
				print("Победил игрок под символом", self.game[0][0])
			elif self.game[0][2] == self.game[1][1] and self.game[1][1] == self.game[2][0]:
				self.gameloop = False
				print("Победил игрок под символом", self.game[0][2])
			elif self.game[0][1] == self.game[1][1] and self.game[1][1] == self.game[2][1]:
				self.gameloop = False
				print("Победил игрок под символом", self.game[0][1])
			elif self.game[0][2] == self.game[1][2] and self.game[1][2] == self.game[2][2]:
				self.gameloop = False
				print("Победил игрок под символом", self.game[0][2])
			elif self.game[0][0] == self.game[1][0] and self.game[1][0] == self.game[2][0]:
				self.gameloop = False
				print("Победил игрок под символом", self.game[0][0])
			if self.count_of_rotations == 9:
				print("Ничья!")
				self.gameloop = False


def dates(date1, date2):
	import datetime
	date1 = datetime.datetime.strptime(date1, "%d.%m.%Y")
	date2 = datetime.datetime.strptime(date2, "%d.%m.%Y")
	return date1-date2

if __name__ == '__main__':
	# print(recursive_num(2, 3))
	# print(couple_summ(2, 5))
	star_line(10)
	print(dates("01.01.2021", "01.01.2022"))
	a = GameTOE()
	a.start()
