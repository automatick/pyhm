import threading as th
import statistics as st
import random as rn
import math as mt
from sympy import isprime as isp


def create_list():
    globals()["is_started"] = True
    globals()["rn_list"] = [rn.randint(0, 100) for _ in range(1000)]
    print(rn_list)
    globals()["is_started"] = False


def avg(a):
    ss = globals()["is_started"]
    while ss:
        pass
    print(st.mean(a))
    return None


def mxx(a):
    ss = globals()["is_started"]
    while ss:
        pass
    print(max(a))
    return None


th.Thread(target=create_list).start()
th.Thread(target=mxx, args=(rn_list, )).start()
th.Thread(target=avg, args=(rn_list, )).start()


def is_prime():
    ss = globals()["is_started"]
    while ss:
        ss = globals()["is_started"]
        pass
    with open("tt.txt", "r") as f:
        a = f.read()
        a = a.replace("[", "")
        a = a.replace("]", "")
        a = a.replace(" ", '')
        a = a.split(",")
    rs = []
    for i in a:
        if isp(int(i)):
            rs.append(i)
    with open("prime.txt", "w") as f:
        f.write(str(rs))


def fact():
    ss = globals()["is_started"]
    while ss:
        ss = globals()["is_started"]
        pass
    rs = []
    with open("tt.txt", "r") as f:
        a = f.read()
        a = a.replace("[", "")
        a = a.replace("]", "")
        a = a.replace(" ", '')
        a = a.split(",")
    for i in a:
        rs.append(mt.factorial(int(i)))
    with open("fact.txt", "w") as f:
        f.write(str(rs))


def create_list_file():
    globals()["is_started"] = True
    with open("tt.txt", "w") as fl:
        globals()["rn_list"] = [rn.randint(1, 100) for _ in range(1000)]
        fl.write(str(rn_list))
    print(rn_list)
    globals()["is_started"] = False


th.Thread(target=create_list_file).start()
th.Thread(target=fact).start()
th.Thread(target=is_prime()).start()