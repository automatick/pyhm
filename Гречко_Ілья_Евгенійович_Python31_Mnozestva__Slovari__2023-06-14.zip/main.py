playersFullName = {
    "1st": "James Bond",
    "2nd": "Jonh Wick",
}


def add_player(dict, name, number):
    dict[name] = number
    return dict


def delete_player(dict, name):
    del dict[name]
    return dict


def find_player(dict, num):
    try:
        return dict[num]
    except:
        return "Player not found"


def change_player(dict, num, new):
    dict[num] = new
    return dict


if __name__ == "__main__":
    print(add_player(playersFullName, "3rd", "Huan Hu"))
    print(delete_player(playersFullName, "2nd"))
    print(find_player(playersFullName, "1st"))
    print(change_player(playersFullName, "2nd", "James Bond"))


def add_word(dict, eng, franc):
    dict[eng] = franc
    return dict


def delete_word(dict, eng):
    del dict[eng]
    return dict


def find_word(dict, eng):
    try:
        return dict[eng]
    except:
        return "Word not found"


def change_word(dict, eng, new_franc):
    dict[eng] = new_franc
    return dict


eng_to_franc_lib = {
    "hi": "bonjour",
    "bye": "au revoir",
    "how are you": "coucou",
}

if __name__ == "__main__":
    print(add_word(eng_to_franc_lib, "hi", "bonjour"))
    print(delete_word(eng_to_franc_lib, "hi"))
    print(find_word(eng_to_franc_lib, "hi"))
    print(change_word(eng_to_franc_lib, "hi", "bonjour"))

worker_dict_contact = {
    "Сергей Дмитриевич": {"phone": "+7 999 999 99 99", "email": "dmitry@ya.ru", "name_of_rank": "Master",
                          "cabinet_number": "2", "skype": "1647654567"}}


def add_contact(dictionary, name, phone, email, name_of_rank, cabinet_number, skype):
    dictionary[name] = dict(phone=phone, email=email, name_of_rank=name_of_rank, cabinet_number=cabinet_number,
                            skype=skype)
    return dictionary


def delete_dict(dictionary, name):
    del dictionary[name]
    return dictionary


def search_worker(dictionary, name):
    try:
        return dictionary[name]
    except:
        return "Worker not found"


def change_worker_values(dictionary, name, container, value):
    dictionary[name][container] = value
    return dictionary


if __name__ == "__main__":
    print(add_contact(worker_dict_contact, "Джон", "+7 999 999 99 99", "dmitry@ya.ru", "Master", "2", "1647654567"))
    print(delete_dict(worker_dict_contact, "Сергей Дмитриевич"))
    print("Данные о пользователе: ", str(search_worker(worker_dict_contact, "Джон"))[1:-1])
    print(change_worker_values(worker_dict_contact, "Джон", "email", "gg@gmail.com"))

# 4th
books_authors = {
    "War and Peace": {"author_name": "Jonh", "janre": "roman", "list_count": "1000", "vudavnictvo": "ranok"}}


def add_book(dictionary, name, author_name, janre, list_count, vudavnictvo):
    dictionary[name] = dict(author_name=author_name, janre=janre, list_count=list_count, vudavnictvo=vudavnictvo)
    return dictionary


def delete_book(dictionary, book):
    del dictionary[book]
    return dictionary


def search_book(dictionary, book):
    try:
        res = dictionary[book]
        return res
    except:
        return "Book not found"


def change_book_values(dictionary, name, container, value):
    dictionary[name][container] = value
    return dictionary

if __name__ == "__main__":
	print(add_book(books_authors, "Romeo and Juliet", "Jonh", "roman", "250", "ranok"))
	print(delete_book(books_authors, "War and Peace"))
	print("Result: ", search_book(books_authors, "Romeo and Juliet"))
	print(change_book_values(books_authors, "Romeo and Juliet", "author", "Wick"))